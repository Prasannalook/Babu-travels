# BABU travels

A Firebase-powered booking website for Babu Travels with a normal user booking page and an admin dashboard.

## What is included

- `index.html` — customer booking page
- `style.css` — site styling for public and admin pages
- `script.js` — booking submission code
- `login.html` — admin login page
- `admin.html` — admin bookings dashboard
- `js/firebase-config.js` — Firebase initialization placeholder
- `js/login.js` — Firebase admin login code
- `js/admin.js` — Firebase admin dashboard code

## Setup without Node.js

This site is now a static Firebase web app. You do not need Node.js to use the front end.

1. Create a Firebase project at https://console.firebase.google.com
2. In Firebase, add a new Web App and copy the config values.
3. In Firebase Authentication, enable Email/Password sign-in.
4. Create an admin user in Authentication with a secure email and password.
5. In Realtime Database, create a database and set rules to allow your app to read/write data.
6. Open `js/firebase-config.js` and confirm the `databaseURL` is set to your Realtime Database endpoint.
7. Open `index.html` in your browser or serve the folder with Live Server.

## Local preview

- If you open `index.html` directly, it should work in modern browsers.
- If the page does not load, install the VS Code Live Server extension and click **Go Live**.
- Live Server will run the app on a local URL like `http://127.0.0.1:5500`.

## Admin pages

- Open `login.html` to sign in as admin.
- After signing in, you can use `admin.html` to see bookings.

## Hosting suggestions

- Use GitHub Pages or any static file host for the website.
- Make sure the site is served over HTTPS so Firebase works correctly.

## Notes

- Bookings are saved directly to Firebase Realtime Database.
- Admin login uses Firebase Authentication.
- You should run the site through a local server (for example, VS Code Live Server) because Firebase module imports may not work via `file://`.
