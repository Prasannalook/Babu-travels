const express = require('express');
const path = require('path');
const fs = require('fs');
const session = require('express-session');

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'admin@babutravels.com';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'admin123';
const BOOKING_FILE = path.join(__dirname, 'data', 'bookings.json');

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || 'change-this-secret',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 24 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname)));

function loadBookings() {
  try {
    const data = fs.readFileSync(BOOKING_FILE, 'utf8');
    return JSON.parse(data || '[]');
  } catch (error) {
    return [];
  }
}

function saveBookings(bookings) {
  fs.mkdirSync(path.dirname(BOOKING_FILE), { recursive: true });
  fs.writeFileSync(BOOKING_FILE, JSON.stringify(bookings, null, 2), 'utf8');
}

function requireAdmin(req, res, next) {
  if (req.session && req.session.admin) {
    return next();
  }
  return res.status(401).json({ error: 'Unauthorized' });
}

app.post('/api/bookings', (req, res) => {
  const { name, phone, from, to, pickup, drop, vehicle, date } = req.body;
  if (!name || !phone || !from || !to || !vehicle || !date) {
    return res.status(400).json({ error: 'Please complete all required fields.' });
  }

  const booking = {
    id: Date.now().toString(),
    name,
    phone,
    from,
    to,
    pickup: pickup || '',
    drop: drop || '',
    vehicle,
    date,
    status: 'new',
    createdAt: new Date().toISOString()
  };

  const bookings = loadBookings();
  bookings.unshift(booking);
  saveBookings(bookings);

  return res.json({ success: true, booking });
});

app.post('/api/admin/login', (req, res) => {
  const { email, password } = req.body;
  if (email === ADMIN_EMAIL && password === ADMIN_PASSWORD) {
    req.session.admin = true;
    req.session.email = email;
    return res.json({ success: true });
  }
  return res.status(401).json({ error: 'Invalid admin credentials.' });
});

app.post('/api/admin/logout', (req, res) => {
  req.session.destroy(() => {
    res.json({ success: true });
  });
});

app.get('/api/admin/me', (req, res) => {
  if (req.session && req.session.admin) {
    return res.json({ email: req.session.email || ADMIN_EMAIL });
  }
  return res.status(401).json({ error: 'Unauthorized' });
});

app.get('/api/bookings', requireAdmin, (req, res) => {
  return res.json(loadBookings());
});

app.listen(PORT, () => {
  console.log(`Server started on http://localhost:${PORT}`);
});
