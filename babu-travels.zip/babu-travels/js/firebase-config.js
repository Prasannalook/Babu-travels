// Import the functions you need from the SDKs you need
import { initializeApp } from 'https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js';
import { getAuth } from 'https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js';
import { getDatabase } from 'https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js';
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAQhDmkX8X48VZTaX0OzgdLT_qoCcYIa18",
  authDomain: "babu-travles.firebaseapp.com",
  databaseURL: "https://babu-travles-default-rtdb.firebaseio.com",
  projectId: "babu-travles",
  storageBucket: "babu-travles.firebasestorage.app",
  messagingSenderId: "579850823243",
  appId: "1:579850823243:web:eef7bd2d7780b52f7c0fce",
  measurementId: "G-Z91ZC279VY"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);

export { auth, db };