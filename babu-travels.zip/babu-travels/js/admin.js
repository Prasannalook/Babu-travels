import { initializeApp }
from 'https://www.gstatic.com/firebasejs/9.23.0/firebase-app.js';

import {
  getDatabase,
  ref,
  onValue
}
from 'https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js';

import {
  getAuth,
  onAuthStateChanged,
  signOut
}
from 'https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js';


// FIREBASE CONFIG

const firebaseConfig = {

  apiKey: "AIzaSyAQhDmkX8X48VZTaX0OzgdLT_qoCcYIa18",

  authDomain: "babu-travles.firebaseapp.com",

  databaseURL:
  "https://babu-travles-default-rtdb.firebaseio.com",

  projectId: "babu-travles",

  storageBucket:
  "babu-travles.firebasestorage.app",

  messagingSenderId: "579850823243",

  appId:
  "1:579850823243:web:eef7bd2d7780b52f7c0fce",

  measurementId: "G-Z91ZC279VY"

};


// INITIALIZE

const app = initializeApp(firebaseConfig);

const db = getDatabase(app);

const auth = getAuth(app);


// ELEMENTS

const bookingsTable =
  document.getElementById("bookings");

const status =
  document.getElementById("status");

const message =
  document.getElementById("message");

const logoutBtn =
  document.getElementById("logoutBtn");


// AUTH CHECK

onAuthStateChanged(auth, (user) => {

  if(user){

    status.innerHTML =
      `Logged in as ${user.email}`;

    loadBookings();

  }

  else{

    window.location.href = "login.html";

  }

});


// LOAD BOOKINGS

function loadBookings(){

  const bookingsRef =
    ref(db, "bookings");

  onValue(bookingsRef, (snapshot) => {

    bookingsTable.innerHTML = "";

    if(snapshot.exists()){

      snapshot.forEach((childSnapshot) => {

        const data = childSnapshot.val();

        const row = `

          <tr>

            <td>${data.customerName || "-"}</td>

            <td>${data.email || "-"}</td>

            <td>${data.phone || "-"}</td>

            <td>${data.fromLocation || "-"}</td>

            <td>${data.vehicle || "-"}</td>

            <td>${data.travelDate || "-"}</td>

            <td>${data.pickupAddress || "-"}</td>

            <td>${data.dropAddress || "-"}</td>

          </tr>

        `;

        bookingsTable.innerHTML += row;

      });

      message.innerHTML =
        "Bookings loaded successfully";

    }

    else{

      message.innerHTML =
        "No bookings found";

    }

  });

}


// LOGOUT

logoutBtn.addEventListener("click", async () => {

  try{

    await signOut(auth);

    window.location.href = "login.html";

  }

  catch(error){

    console.error(error);

  }

});