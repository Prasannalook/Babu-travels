import { auth } from './firebase-config.js';

import {
  signInWithEmailAndPassword
} from 'https://www.gstatic.com/firebasejs/9.23.0/firebase-auth.js';

document.addEventListener('DOMContentLoaded', () => {

  const loginForm =
    document.getElementById('loginForm');

  if (!loginForm) return;

  loginForm.addEventListener('submit', async (event) => {

    event.preventDefault();

    // INPUTS

    const email =
      document.getElementById('email')
      .value
      .trim();

    const password =
      document.getElementById('password')
      .value
      .trim();

    // BUTTON

    const submitButton =
      loginForm.querySelector('button');

    // EMAIL VALIDATION

    const emailPattern =
      /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailPattern.test(email)) {

      alert('Please enter a valid email address.');

      return;
    }

    // PASSWORD VALIDATION

    if (password.length < 6) {

      alert('Password must be at least 6 characters.');

      return;
    }

    // LOADING

    submitButton.disabled = true;

    submitButton.innerText = 'Signing In...';

    try {

      // FIREBASE LOGIN

      await signInWithEmailAndPassword(
        auth,
        email,
        password
      );

      // SUCCESS MESSAGE

      alert('Login Successful');

      // REDIRECT

      window.location.href = 'admin.html';

    } catch (error) {

      console.error(error);

      // FRIENDLY ERRORS

      switch(error.code){

        case 'auth/user-not-found':

          alert('User not found.');

          break;

        case 'auth/wrong-password':

          alert('Incorrect password.');

          break;

        case 'auth/invalid-email':

          alert('Invalid email format.');

          break;

        default:

          alert('Login failed. Please try again.');

      }

    } finally {

      submitButton.disabled = false;

      submitButton.innerText = 'Sign In';

    }

  });

});