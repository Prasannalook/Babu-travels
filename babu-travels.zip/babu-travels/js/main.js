document.addEventListener('DOMContentLoaded', () => {
  const heroBtn = document.querySelector('.btn');
  if (heroBtn) {
    heroBtn.addEventListener('click', (event) => {
      event.preventDefault();
      const servicesSection = document.querySelector('#services');
      if (servicesSection) {
        servicesSection.scrollIntoView({ behavior: 'smooth' });
      }
    });
  }
});
