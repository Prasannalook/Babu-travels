import { db } from './js/firebase-config.js';
import { ref, push, set, serverTimestamp } from 'https://www.gstatic.com/firebasejs/9.23.0/firebase-database.js';

document.addEventListener('DOMContentLoaded', () => {
  const bookingForm = document.getElementById('bookingForm');
  const dateInput = document.getElementById('date');
  if (!bookingForm || !dateInput) return;

  const today = new Date().toISOString().split('T')[0];
  dateInput.setAttribute('min', today);

  bookingForm.addEventListener('submit', async function(e) {
    e.preventDefault();

    if (!bookingForm.checkValidity()) {
      bookingForm.reportValidity();
      return;
    }

    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const from = document.getElementById('from').value.trim();
    const to = document.getElementById('to').value.trim();
    const pickup = document.getElementById('pickup').value.trim();
    const drop = document.getElementById('drop').value.trim();
    const vehicle = document.getElementById('vehicle').value;
    const date = document.getElementById('date').value;
    const route = `${from} → ${to}`;

    const newBookingRef = push(ref(db, 'bookings'));

    try {
      await set(newBookingRef, {
        name,
        email,
        phone,
        route,
        from,
        to,
        pickup,
        drop,
        vehicle,
        date,
        status: 'new',
        createdAt: Date.now()
      });

      alert('Booking submitted successfully!');
      bookingForm.reset();
    } catch (error) {
      alert('Booking failed. Please try again.');
      console.error(error);
    }
  });

  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', event => {
      const targetId = anchor.getAttribute('href').substring(1);
      const targetElement = document.getElementById(targetId);
      if (targetElement) {
        event.preventDefault();
        targetElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });
});
